"""Run supplier reconciliation from config.json beside this script or executable."""

from __future__ import annotations

import json
import os
import re
import sys
import traceback
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any

from openpyxl import load_workbook

from reconcile_statements import build_output, load_aliases, write_workbook


CONFIG_FILENAME = "config.json"
NO_PAUSE_ENV = "RECONCILIATION_NO_PAUSE"


def application_dir() -> Path:
    """Return the executable folder after packaging, or the source folder otherwise."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def config_path_from_argv() -> Path:
    if len(sys.argv) > 2:
        raise RuntimeError("只接受一个可选参数：config.json 路径")
    if len(sys.argv) == 2:
        path = Path(sys.argv[1]).expanduser()
        return path.resolve() if path.is_absolute() else (Path.cwd() / path).resolve()
    return application_dir() / CONFIG_FILENAME


def load_config(path: Path) -> dict[str, Any]:
    if not path.is_file():
        raise RuntimeError(f"未找到配置文件：{path}\n请把 config.json 放在程序旁边。")
    try:
        payload = json.loads(path.read_text(encoding="utf-8-sig"))
    except json.JSONDecodeError as exc:
        raise RuntimeError(f"config.json 格式错误：第 {exc.lineno} 行，第 {exc.colno} 列") from exc
    if not isinstance(payload, dict):
        raise RuntimeError("config.json 顶层必须是 JSON 对象")
    return payload


def required_text(config: dict[str, Any], key: str) -> str:
    value = str(config.get(key, "")).strip()
    if not value:
        raise RuntimeError(f"config.json 缺少必填项：{key}")
    return value


def number_value(config: dict[str, Any], key: str, default: float) -> float:
    value = config.get(key, default)
    if isinstance(value, bool):
        raise RuntimeError(f"{key} 必须是数字")
    try:
        result = float(value)
    except (TypeError, ValueError) as exc:
        raise RuntimeError(f"{key} 必须是数字") from exc
    if result < 0:
        raise RuntimeError(f"{key} 不能小于 0")
    return result


def positive_int(config: dict[str, Any], key: str, default: int) -> int:
    value = config.get(key, default)
    if isinstance(value, bool):
        raise RuntimeError(f"{key} 必须是正整数")
    try:
        result = int(value)
    except (TypeError, ValueError) as exc:
        raise RuntimeError(f"{key} 必须是正整数") from exc
    if result < 1:
        raise RuntimeError(f"{key} 必须是正整数")
    return result


def format_path_template(value: str, month: str, now: datetime) -> str:
    variables = {
        "month": month,
        "date": now.strftime("%Y-%m-%d"),
        "datetime": now.strftime("%Y%m%d-%H%M%S"),
    }
    try:
        return value.format(**variables)
    except KeyError as exc:
        allowed = "{month}、{date}、{datetime}"
        raise RuntimeError(f"路径使用了未知占位符 {exc}；仅支持 {allowed}") from exc


def resolve_config_path(base_dir: Path, value: str, month: str, now: datetime) -> Path:
    rendered = format_path_template(value, month, now)
    expanded = os.path.expandvars(os.path.expanduser(rendered))
    path = Path(expanded)
    return path.resolve() if path.is_absolute() else (base_dir / path).resolve()


def configured_aliases(config: dict[str, Any]) -> dict[str, list[str]]:
    aliases = load_aliases(None)
    custom = config.get("供应商别名", {})
    if custom in (None, ""):
        return aliases
    if not isinstance(custom, dict):
        raise RuntimeError("供应商别名 必须是 JSON 对象")
    for supplier, values in custom.items():
        if isinstance(values, str):
            values = [values]
        if not isinstance(values, list) or not all(isinstance(item, str) for item in values):
            raise RuntimeError(f"供应商别名 {supplier} 必须是字符串或字符串数组")
        aliases[str(supplier)] = [item.strip() for item in values if item.strip()]
    return aliases


def verify_result_workbook(path: Path, expected_suppliers: int) -> None:
    wb = load_workbook(path, data_only=True, read_only=True)
    try:
        required_sheets = {"汇总结果", "明细差异", "未匹配文件", "说明"}
        missing = required_sheets - set(wb.sheetnames)
        if missing:
            raise RuntimeError(f"结果文件缺少工作表：{', '.join(sorted(missing))}")
        rows = list(wb["汇总结果"].iter_rows(min_row=2, values_only=True))
        if len(rows) != expected_suppliers:
            raise RuntimeError(f"结果供应商行数异常：预期 {expected_suppliers}，实际 {len(rows)}")
        if any(not row[8] for row in rows):
            raise RuntimeError("结果文件存在空状态")
        for row in rows:
            for column in (1, 2, 3, 4, 5, 6):
                value = row[column]
                if value is not None and not isinstance(value, (int, float)):
                    raise RuntimeError("结果文件的数量或金额差异列不是数值格式")
    finally:
        wb.close()


def run_from_config(config_path: Path, config: dict[str, Any]) -> dict[str, Any]:
    base_dir = config_path.parent
    now = datetime.now()
    month = required_text(config, "对账月份")
    if not re.fullmatch(r"\d{4}-(?:0?[1-9]|1[0-2])", month):
        raise RuntimeError("对账月份 格式应为 YYYY-MM，例如 2026-06")

    main_path = resolve_config_path(base_dir, required_text(config, "总表路径"), month, now)
    statement_dir = resolve_config_path(base_dir, required_text(config, "供应商文件夹路径"), month, now)
    output_path = resolve_config_path(base_dir, required_text(config, "输出Excel路径"), month, now)
    audit_value = str(config.get("审计JSON路径", "")).strip()
    audit_path = resolve_config_path(base_dir, audit_value, month, now) if audit_value else None

    if not main_path.is_file():
        raise RuntimeError(f"总表不存在：{main_path}")
    if main_path.suffix.lower() != ".xlsx":
        raise RuntimeError("总表路径 必须指向 .xlsx 文件")
    if not statement_dir.is_dir():
        raise RuntimeError(f"供应商文件夹不存在：{statement_dir}")
    if output_path.suffix.lower() != ".xlsx":
        raise RuntimeError("输出Excel路径 必须以 .xlsx 结尾")
    if output_path == main_path:
        raise RuntimeError("输出Excel路径 不能覆盖总表")
    if audit_path and audit_path.suffix.lower() != ".json":
        raise RuntimeError("审计JSON路径 必须为空或以 .json 结尾")

    main_sheet = str(config.get("总表工作表", "")).strip() or None
    main_header_row = positive_int(config, "总表表头行", 3)
    main_data_row = positive_int(config, "总表数据起始行", main_header_row + 1)
    if main_data_row <= main_header_row:
        raise RuntimeError("总表数据起始行 必须大于 总表表头行")

    quantity_tolerance = number_value(config, "数量容差", 0.000001)
    amount_tolerance = number_value(config, "金额容差", 0.01)
    aliases = configured_aliases(config)

    data = build_output(
        main_path=main_path,
        statement_dir=statement_dir,
        output_xlsx=output_path,
        month=month,
        main_sheet=main_sheet,
        main_header_row=main_header_row,
        main_data_row=main_data_row,
        qty_tolerance=quantity_tolerance,
        amount_tolerance=amount_tolerance,
        aliases=aliases,
    )
    write_workbook(data, output_path)
    verify_result_workbook(output_path, int(data["meta"]["main_supplier_count"]))

    if audit_path:
        audit_path.parent.mkdir(parents=True, exist_ok=True)
        audit_path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    status_counts: dict[str, int] = defaultdict(int)
    for row in data["summary"]:
        status_counts[str(row[8])] += 1
    return {
        "总表供应商数": data["meta"]["main_supplier_count"],
        "供应商文件数": data["meta"]["statement_file_count"],
        "完成": status_counts.get("完成", 0),
        "金额或数量不一致": status_counts.get("未完成-金额/数量不一致", 0),
        "未找到对账单": status_counts.get("未完成-未找到对账单", 0),
        "需复核": status_counts.get("需复核", 0),
        "输出文件": str(output_path),
        "审计文件": str(audit_path) if audit_path else "未生成",
    }


def should_pause(config: dict[str, Any]) -> bool:
    return (
        bool(config.get("运行结束后暂停", True))
        and os.environ.get(NO_PAUSE_ENV) != "1"
        and sys.stdin.isatty()
    )


def main() -> int:
    config: dict[str, Any] = {}
    try:
        config_path = config_path_from_argv()
        config = load_config(config_path)
        result = run_from_config(config_path, config)
        print("\n核对完成")
        print(json.dumps(result, ensure_ascii=False, indent=2))
        exit_code = 0
    except Exception as exc:
        print(f"\n核对失败：{exc}", file=sys.stderr)
        if bool(config.get("显示详细错误", False)):
            traceback.print_exc()
        exit_code = 1
    if should_pause(config):
        input("\n按回车键关闭窗口...")
    return exit_code


if __name__ == "__main__":
    raise SystemExit(main())
