#!/bin/zsh
set -e
cd "$(dirname "$0")"

if [[ ! -x ".build-venv/bin/python" ]]; then
  if command -v python3.12 >/dev/null 2>&1; then
    python3.12 -m venv .build-venv
  elif command -v python3.11 >/dev/null 2>&1; then
    python3.11 -m venv .build-venv
  else
    python3 -m venv .build-venv
  fi
fi

source .build-venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements-build.txt
python -m PyInstaller --noconfirm --clean --onefile --name supplier_reconciliation_tool --collect-all pypdfium2 run_reconciliation.py

cp config.json dist/config.json
cp README.md dist/README.md

echo
echo "打包完成：$PWD/dist"
echo "config.json 必须和 supplier_reconciliation_tool 放在同一目录。"
read "?按回车键关闭窗口..."
