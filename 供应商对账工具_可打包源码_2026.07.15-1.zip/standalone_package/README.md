# 供应商对账工具（可打包源码）

## 使用方式

1. 把采购总表和供应商对账单文件夹放到本目录，或在 `config.json` 中填写绝对路径。
2. 修改 `config.json` 的总表路径、供应商文件夹路径、对账月份和输出路径。
3. 首次源码运行先安装依赖：`python -m pip install -r requirements.txt`。
4. 源码运行：`python run_reconciliation.py`。
5. 打包后运行：双击 `dist/supplier_reconciliation_tool.exe`（Windows）或 `dist/supplier_reconciliation_tool`（macOS）。

所有相对路径都以 `config.json` 所在目录为准。打包后必须把 `config.json` 放在可执行文件旁边，改配置不需要重新打包。

## 路径占位符

- `{month}`：对账月份，例如 `2026-06`
- `{date}`：运行日期，例如 `2026-07-15`
- `{datetime}`：运行时间，例如 `20260715-103000`

示例：`输出/供应商对账核对结果_{month}_{date}.xlsx`

## 打包

- Windows：双击 `build_windows.bat`。需要先安装 64 位 Python 3.11 或 3.12。
- macOS：双击 `build_macos.command`。需要先安装 Python 3.11 或 3.12。

Windows 的 `.exe` 必须在 Windows 上打包；macOS 生成的文件不能直接拿到 Windows 运行。打包结果位于 `dist`，其中包含可执行文件、`config.json` 和本说明。

## config.json 字段

- `总表路径`：采购明细 `.xlsx` 文件。
- `供应商文件夹路径`：程序会递归读取其中的 `.xlsx`、`.xls`、`.pdf`。
- `对账月份`：`YYYY-MM` 格式，用于选择正确月份的工作表。
- `输出Excel路径`：核对结果文件。
- `审计JSON路径`：留空表示不生成 JSON 审计文件。
- `总表工作表`：留空时读取活动工作表。
- `总表表头行`、`总表数据起始行`：默认分别为 3 和 4。
- `数量容差`、`金额容差`：默认分别为 `0.000001` 和 `0.01`。
- `供应商别名`：总表供应商名称到文件名称别名的映射。
- `运行结束后暂停`：双击运行时是否等待用户查看结果。
- `显示详细错误`：排查问题时可改为 `true`。

结果 Excel 包含 `汇总结果`、`明细差异`、`未匹配文件` 和 `说明` 四个工作表。程序生成后会重新打开结果文件，检查供应商行数、状态和数值列。
