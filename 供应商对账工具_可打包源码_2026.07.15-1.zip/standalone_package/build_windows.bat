@echo off
setlocal
cd /d "%~dp0"

if not exist ".build-venv\Scripts\python.exe" (
  py -3.12 -m venv .build-venv 2>nul
  if errorlevel 1 py -3.11 -m venv .build-venv 2>nul
  if errorlevel 1 python -m venv .build-venv
)

if not exist ".build-venv\Scripts\python.exe" (
  echo Build failed: Python 3.11 or 3.12 is required.
  pause
  exit /b 1
)

call ".build-venv\Scripts\activate.bat"
python -m pip install --upgrade pip
python -m pip install -r requirements-build.txt
python -m PyInstaller --noconfirm --clean --onefile --name supplier_reconciliation_tool --collect-all pypdfium2 run_reconciliation.py

copy /Y config.json "dist\config.json" >nul
copy /Y README.md "dist\README.md" >nul

echo.
echo Build completed: %CD%\dist
echo Keep config.json beside supplier_reconciliation_tool.exe.
pause
