param(
  [string]$Python = "python",
  [string]$NodePackageManager = "npm",
  [switch]$SkipInstaller
)

$ErrorActionPreference = "Stop"
$Root = Resolve-Path (Join-Path $PSScriptRoot "..")
$Backend = Join-Path $Root "backend"
$Frontend = Join-Path $Root "frontend"
$BuildDir = Join-Path $PSScriptRoot "build"
$Venv = Join-Path $PSScriptRoot ".venv-build"

Write-Host "== Resume Match Windows Builder =="
Write-Host "Project: $Root"

if (!(Test-Path $Venv)) {
  Write-Host "Creating Python build environment..."
  & $Python -m venv $Venv
}

$Py = Join-Path $Venv "Scripts\python.exe"

Write-Host "Installing backend dependencies..."
& $Py -m pip install --upgrade pip
& $Py -m pip install -r (Join-Path $Backend "requirements.txt")
& $Py -m pip install pyinstaller

Write-Host "Building frontend..."
Push-Location $Frontend
try {
  if ($NodePackageManager -eq "pnpm") {
    pnpm install
    pnpm run build
  } else {
    npm install
    npm run build
  }
} finally {
  Pop-Location
}

if (Test-Path $BuildDir) {
  Remove-Item $BuildDir -Recurse -Force
}
New-Item -ItemType Directory -Force -Path $BuildDir | Out-Null

Write-Host "Building server executable..."
Push-Location $Root
try {
  & $Py -m PyInstaller (Join-Path $PSScriptRoot "resume-match-server.spec") --distpath $BuildDir --workpath (Join-Path $PSScriptRoot "pyinstaller-work") --clean --noconfirm
} finally {
  Pop-Location
}

Copy-Item (Join-Path $PSScriptRoot "scripts\Start Resume Match.bat") $BuildDir -Force
Copy-Item (Join-Path $PSScriptRoot "scripts\Stop Resume Match.bat") $BuildDir -Force
Copy-Item (Join-Path $PSScriptRoot "scripts\Show LAN Address.bat") $BuildDir -Force
Copy-Item (Join-Path $Backend ".env.example") (Join-Path $BuildDir ".env.sample") -Force

if (!$SkipInstaller) {
  $Iscc = Get-Command "iscc" -ErrorAction SilentlyContinue
  if ($Iscc) {
    Write-Host "Building installer with Inno Setup..."
    & $Iscc.Source (Join-Path $PSScriptRoot "installer.iss")
  } else {
    Write-Host "Inno Setup is not installed. Skipping .exe installer."
    Write-Host "Portable package is ready at: $BuildDir"
  }
}

Write-Host "Done."
Write-Host "Portable package: $BuildDir"
