#define MyAppName "简历匹配系统"
#define MyAppVersion "1.0.0"
#define MyAppPublisher "jooan"
#define MyAppExeName "resume-match-server.exe"

[Setup]
AppId={{C6F8BA8D-70E7-4F50-ACF4-1E7C1ECA8083}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\ResumeMatch
DisableProgramGroupPage=yes
OutputDir=output
OutputBaseFilename=ResumeMatchSetup
Compression=lzma
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin

[Languages]
Name: "chinesesimp"; MessagesFile: "compiler:Languages\ChineseSimplified.isl"

[Files]
Source: "build\resume-match-server.exe"; DestDir: "{app}"; Flags: ignoreversion
Source: "build\.env.sample"; DestDir: "{app}"; Flags: ignoreversion onlyifdoesntexist
Source: "scripts\Start Resume Match.bat"; DestDir: "{app}"; Flags: ignoreversion
Source: "scripts\Stop Resume Match.bat"; DestDir: "{app}"; Flags: ignoreversion
Source: "scripts\Show LAN Address.bat"; DestDir: "{app}"; Flags: ignoreversion

[Icons]
Name: "{autodesktop}\简历匹配系统"; Filename: "{app}\Start Resume Match.bat"; WorkingDir: "{app}"
Name: "{autoprograms}\简历匹配系统"; Filename: "{app}\Start Resume Match.bat"; WorkingDir: "{app}"
Name: "{autoprograms}\停止简历匹配系统"; Filename: "{app}\Stop Resume Match.bat"; WorkingDir: "{app}"
Name: "{autoprograms}\查看局域网访问地址"; Filename: "{app}\Show LAN Address.bat"; WorkingDir: "{app}"

[Run]
Filename: "netsh"; Parameters: "advfirewall firewall add rule name=""Resume Match 8083"" dir=in action=allow protocol=TCP localport=8083"; Flags: runhidden
Filename: "{app}\Start Resume Match.bat"; Description: "启动简历匹配系统"; Flags: postinstall nowait skipifsilent

[UninstallRun]
Filename: "{app}\Stop Resume Match.bat"; Flags: runhidden waituntilterminated
Filename: "netsh"; Parameters: "advfirewall firewall delete rule name=""Resume Match 8083"""; Flags: runhidden
