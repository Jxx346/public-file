# Windows 本地局域网安装包

目标：把简历匹配系统安装到一台 Windows 电脑上。该电脑不需要提前安装 Python、数据库或 Node。安装后这台电脑自己能用，同一个局域网里的其他电脑也能访问。

## 用户使用方式

1. 双击 `ResumeMatchSetup.exe` 安装。
2. 桌面打开“简历匹配系统”。
3. 本机访问：`http://127.0.0.1:8083`
4. 局域网访问：运行“查看局域网访问地址”，把显示的 `http://局域网IP:8083` 发给同事。

数据保存在安装目录：

- `data/resume_match.db`
- `uploads/`
- `.env`

## API Key

安装后编辑安装目录里的 `.env`，填写：

```env
AI_PROVIDER=qwen
AI_API_KEY=你的千问Key
AI_MODEL=qwen3.7-plus
AI_FAST_ANALYSIS=true
AI_FAST_MODEL=qwen3.6-flash
QWEN_DISABLE_THINKING=true
AI_BASE_URL=https://dashscope.aliyuncs.com/compatible-mode/v1
```

密钥只存在这台 Windows 电脑本地，不进入前端和数据库。

## 构建安装包

在 Windows 构建机安装：

- Python 3.12+
- Node.js 20+
- Inno Setup 6

然后在项目根目录运行：

```powershell
cd windows-installer
.\build_windows.ps1
```

产物：

- 绿色便携包：`windows-installer\build\`
- 安装包：`windows-installer\output\ResumeMatchSetup.exe`

如果没有安装 Inno Setup，脚本会只生成绿色便携包。

## 局域网访问要求

- 安装时需要管理员权限，用于添加 Windows 防火墙规则。
- 服务监听 `0.0.0.0:8083`。
- 其他电脑必须和安装电脑在同一个局域网。
- 安装电脑关机或休眠后，其他电脑无法访问。

## 限制

- `.docx`、PDF、图片、TXT 正常支持。
- 旧 `.doc` 在 Windows 打包版里不保证可解析，建议转成 `.docx` 或 PDF。
