@echo off
setlocal
cd /d "%~dp0"

if not exist ".env" (
  copy ".env.sample" ".env" >nul
)

if not exist "data" mkdir "data"
if not exist "uploads" mkdir "uploads"

tasklist /FI "IMAGENAME eq resume-match-server.exe" | find /I "resume-match-server.exe" >nul
if errorlevel 1 (
  start "Resume Match Server" /min "%~dp0resume-match-server.exe"
)

powershell -NoProfile -ExecutionPolicy Bypass -Command "$url='http://127.0.0.1:8083/api/health'; for($i=0;$i -lt 30;$i++){ try { Invoke-RestMethod $url -TimeoutSec 1 | Out-Null; Start-Process 'http://127.0.0.1:8083'; exit 0 } catch { Start-Sleep -Seconds 1 } }; Start-Process 'http://127.0.0.1:8083'"

call "%~dp0Show LAN Address.bat"
