@echo off
setlocal
echo.
echo 本机访问地址:
echo   http://127.0.0.1:8083
echo.
echo 局域网其他电脑访问地址:
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '127.*' -and $_.PrefixOrigin -ne 'WellKnown' } | ForEach-Object { '  http://' + $_.IPAddress + ':8083' }"
echo.
echo 如果局域网电脑打不开，请确认:
echo 1. 这台电脑开机且软件正在运行
echo 2. Windows 防火墙允许 8083 端口
echo 3. 对方电脑和这台电脑在同一个局域网
echo.
pause
