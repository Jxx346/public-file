@echo off
taskkill /IM resume-match-server.exe /F >nul 2>nul
echo 简历匹配系统已停止。
pause
